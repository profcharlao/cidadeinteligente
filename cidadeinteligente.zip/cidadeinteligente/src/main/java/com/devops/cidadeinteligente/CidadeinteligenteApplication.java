package com.devops.cidadeinteligente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CidadeinteligenteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CidadeinteligenteApplication.class, args);
	}

}
