package com.devops.cidadeinteligente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CidadeinteligenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
